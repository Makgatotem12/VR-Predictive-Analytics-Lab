
using UnityEngine;
using UnityEngine.Networking;
using TMPro;

public class DataSender : MonoBehaviour
{
    public TMP_Text predictionText;

    public void OnSliderChanged(float value)
    {
        StartCoroutine(SendDataToBackend(value));
    }

    IEnumerator SendDataToBackend(float inputValue)
    {
        string url = "http://localhost:5000/predict";
        WWWForm form = new WWWForm();
        form.AddField("input", inputValue.ToString());

        using (UnityWebRequest www = UnityWebRequest.Post(url, form))
        {
            yield return www.SendWebRequest();

            if (www.result == UnityWebRequest.Result.Success)
            {
                predictionText.text = "Prediction: " + www.downloadHandler.text;
            }
            else
            {
                predictionText.text = "Error!";
            }
        }
    }
}
