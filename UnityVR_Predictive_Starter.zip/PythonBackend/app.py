
from flask import Flask, request
from flask_cors import CORS
import numpy as np
from sklearn.linear_model import LinearRegression

app = Flask(__name__)
CORS(app)

# Fake dataset: Ad Spend vs Sales
X = np.array([[10], [20], [30], [40], [50]])
y = np.array([15, 25, 40, 45, 60])
model = LinearRegression().fit(X, y)

@app.route("/predict", methods=["POST"])
def predict():
    input_val = float(request.form["input"])
    prediction = model.predict([[input_val]])[0]
    return str(round(prediction, 2))

if __name__ == "__main__":
    app.run(debug=True)
